#!/bin/bash

source_directory1="/home/loping151/Disks/TiPlus7100/data/tools/local_data/recon_glb"
source_directory2="/home/loping151/Disks/TiPlus7100/data/tools/local_data/rotate_glb"

process_directory() {
    local directory=$1

    python stage4_launch_render_eval.py --DATA_DIR "$directory"

    echo "Done: $directory"
}

max_jobs=6

for directory in "$source_directory1"/*; do
    if [ -d "$directory" ]; then
        dirname=$(basename "$directory")

        process_directory "$directory" "$target_directory" &

        if (( $(jobs -r | wc -l) >= max_jobs )); then
            wait -n
        fi
    fi
done

for directory in "$source_directory2"/*; do
    if [ -d "$directory" ]; then
        dirname=$(basename "$directory")

        process_directory "$directory" "$target_directory" &

        if (( $(jobs -r | wc -l) >= max_jobs )); then
            wait -n
        fi
    fi
done

wait
echo "All done."
