#!/bin/bash

source_directory="/home/loping151/Disks/TiPlus7100/data/prepared_data"

process_directory() {
    local directory=$1

    python stage2_launch_render_eval.py --DATA_DIR "$directory"

    echo "Done: $directory"
}

max_jobs=6

for directory in "$source_directory"/*; do
    if [ -d "$directory" ]; then
        dirname=$(basename "$directory")

        process_directory "$directory" "$target_directory" &

        if (( $(jobs -r | wc -l) >= max_jobs )); then
            wait -n
        fi
    fi
done

wait
echo "All done."
