#!/bin/bash

source_directory="/home/loping151/Disks/TiPlus7100/data/tools/local_data/original_glb"
target_root_directory="/home/loping151/Disks/TiPlus7100/data/tools/local_data/original_ply"

process_directory() {
    local directory=$1
    local target_directory=$2

    mkdir -p "$target_directory"
    python prepare_data_glb.py "$directory" "$target_directory"
    echo "Done: $directory"
}

for directory in "$source_directory"/*; do
    if [ -d "$directory" ]; then
        dirname=$(basename "$directory")
        target_directory="$target_root_directory/$dirname"

        process_directory "$directory" "$target_directory" &
    fi
done

wait
echo "All done."
