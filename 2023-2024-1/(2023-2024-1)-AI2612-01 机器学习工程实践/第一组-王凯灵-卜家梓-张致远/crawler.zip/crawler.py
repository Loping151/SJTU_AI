# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver import EdgeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import time
import warnings
import pdb
import os

warnings.filterwarnings("ignore")

if __name__ == "__main__":


	page = "https://sketchfab.com/search?features=downloadable&q=SOFA&type=models"#搜索主页，搜别的数据只需要改q="   "

	download_directory = r'D:\sofa' #下载路径

	email = "zhangzhiyuanzzy@sjtu.edu.cn"
	password = "909089ZZYzzy"

	opt = EdgeOptions()

	EdgeOptions.add_experimental_option(opt,name = "prefs", value = {
    "download.default_directory": download_directory,
    "download.prompt_for_download": False,  
    "profile.default_content_settings.popups": 0 })

	driver = webdriver.Edge(executable_path='./msedgedriver.exe',options=opt )

	#driver.maximize_window()
	# options = webdriver.ChromeOptions()
	# options.add_argument('--headless')
	# driver = webdriver.Chrome(chrome_options=options)

	#自动登录
	driver.get("https://sketchfab.com/login")

	time.sleep(1)

	email_field = driver.find_element(By.CSS_SELECTOR,'input[type="email"]')
	password_field = driver.find_element(By.CSS_SELECTOR,'input[type="password"]')
	login_button = driver.find_element(By.CSS_SELECTOR,'div[class="form-field form-buttons login-field"]')

	email_field.send_keys(email)
	password_field.send_keys(password)
	login_button.click()

	time.sleep(3)

	pdb.set_trace()
	
	

	driver.get(page)
	idx = 0

	time.sleep(3)


	# 找到所有的显示模型的卡片
	
	cards = driver.find_elements(By.CSS_SELECTOR,'div[class="card__main__corner --top-right"]')


	#把cookie提示框按掉
	reject_cookie_button =driver.find_element(By.ID,'onetrust-reject-all-handler')
	reject_cookie_button.click()

	time.sleep(5)

	log = open(os.path.join(download_directory,'log.txt'), 'a+')
	log.seek(0)

	downloaded_list = lines = [line.strip() for line in log.readlines()]
	actions = ActionChains(driver)


	#pdb.set_trace()


	for card in cards:

		#在卡片上部找到下载按钮，同时跳过付费资源

		button_list = card.find_elements(By.CSS_SELECTOR,'a')

		if len(button_list) == 0:
			continue

		button= button_list[0]

		href_attribute = button.get_attribute("href")
		log.write(href_attribute)
		log.write('\n')
		
		
		page_height = driver.execute_script("return document.body.scrollHeight;")
		page_width = driver.execute_script("return document.body.scrollWidth;")	

        #到底部了就往下滚动，收集合并新加载的卡片信息

		if button.location['y'] > page_height:
			card.location_once_scrolled_into_view
			#driver.execute_script("window.scrollTo( 0, document.body.scrollHeight*1.2);")
			button = card.find_element(By.CSS_SELECTOR,'a')
			
			new_cards_list = driver.find_elements(By.CSS_SELECTOR,'div[class="card__main__corner --top-right"]')
			new_elements = [item for item in new_cards_list if item not in cards]
			for new_element in new_elements:
				cards.append(new_element)

		if card == cards[-1]:
			card.location_once_scrolled_into_view

			#driver.execute_script("window.scrollTo( 0, document.body.scrollHeight*1.5);")
			time.sleep(3)
			new_cards_list = driver.find_elements(By.CSS_SELECTOR,'div[class="card__main__corner --top-right"]')
			new_elements = [item for item in new_cards_list if item not in cards]		
			for new_element in new_elements:
				cards.append(new_element)


		
		if href_attribute in downloaded_list and idx!=0:
			continue
		
		
		print(idx)
		idx+=1
		
		#点击卡片上的下载按钮进入下载界面

		button.click()

		#等待页面加载完成。如果这里报错就是被制裁了。
		
		WebDriverWait(driver, 15).until(EC.visibility_of_element_located((By.CSS_SELECTOR,'div[class="jv075PB9"]')))

		
		#找到下载gltf文件的按钮并点击
		download_button_links = driver.find_element(By.CSS_SELECTOR,'div[class="c-download__links"]')

		gltf_text = driver.find_element(By.XPATH,"//*[contains(text(), '.gltf')]")
		tep = gltf_text.find_element(By.XPATH, "./../..")
		download_button = tep.find_element(By.CSS_SELECTOR,'button')

		if href_attribute not in downloaded_list:	
			download_button.click()

		#等待一段时间否则可能不会正常下载
		time.sleep(5)

		#找到两个界面的关闭按钮并回到搜索主页

		esc_button1 = driver.find_element(By.CSS_SELECTOR,'a[class="c-popup__close"]')

		esc_button1.click()

		time.sleep(1)

		esc_button2 = driver.find_element(By.CSS_SELECTOR,'a[class="c-model-page-popup__close fa-regular fa-times"]')

		esc_button2.click()

		time.sleep(2)

	pdb.set_trace()

	

	driver.close()
