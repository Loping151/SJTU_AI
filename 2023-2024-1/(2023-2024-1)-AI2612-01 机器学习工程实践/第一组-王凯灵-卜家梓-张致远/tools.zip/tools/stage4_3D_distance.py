import pandas as pd
import numpy as np
import open3d as o3d
import os
from tqdm import tqdm

debug = False

def try_load_ply(file_path):
    mesh = o3d.io.read_triangle_mesh(file_path, print_progress=False)
    if mesh.triangles:
        return mesh, "Mesh"

    pcd = o3d.io.read_point_cloud(file_path, print_progress=False)
    if pcd.points:
        return mesh, "PointCloud"

    return None, "Unknown"

def load_and_normalize_pcd(file_path, color=[1, 0, 0, 0.5]):
    assert os.path.exists(file_path), f"File {file_path} not found."
    pcd, pcd_type = try_load_ply(file_path)
    if pcd_type == "Mesh":
        pcd = pcd.sample_points_uniformly(number_of_points=100000)
    elif pcd_type != "PointCloud":
        raise ValueError(f"Unsupported file type: {file_path}")
    mean_point = np.mean(np.asarray(pcd.points), axis=0)
    pcd.points = o3d.utility.Vector3dVector(np.asarray(pcd.points) - mean_point)
    max_bound = np.max(np.asarray(pcd.points), axis=0)
    min_bound = np.min(np.asarray(pcd.points), axis=0)
    pcd.scale(1 / np.max(max_bound - min_bound), center=pcd.get_center())

    if debug:
        pcd.paint_uniform_color(color[:3])
        pcd.colors = o3d.utility.Vector3dVector(np.asarray(pcd.colors) * color[3])
    return pcd

def sample_points(pcd, voxel_size=0.0005):
    if voxel_size > 0:
        pcd = pcd.voxel_down_sample(voxel_size)
    return pcd

def compute_chamfer_distance(pcd1, pcd2):
    dist1 = pcd1.compute_point_cloud_distance(pcd2)
    dist2 = pcd2.compute_point_cloud_distance(pcd1)
    chamfer_dist = np.mean(dist1) + np.mean(dist2)
    return chamfer_dist

if __name__ == "__main__":
    result = np.load('./store/stage4_clip.npy', allow_pickle=True).item()
    result['3D_distance'] = []
    
    for category, model_hash in tqdm(zip(result['category'], result['model_hash'])):
        try:
            # While we use glb to render, we use ply to compute 3D distance.
            recon_ply_path = f'local_data/recon_ply/{category}/{model_hash}.ply'
            rotate_ply_path = f'local_data/rotate_ply/{category}/{model_hash}.ply'
            recon_pcd = sample_points(load_and_normalize_pcd(recon_ply_path))
            rotate_pcd = sample_points(load_and_normalize_pcd(rotate_ply_path, [0, 0, 1, 0.5]))
            if debug:
                o3d.visualization.draw_geometries([recon_pcd, rotate_pcd])
                exit()
            result['3D_distance'].append(compute_chamfer_distance(recon_pcd, rotate_pcd))
        except FileNotFoundError:
            result['3D_distance'].append(-1)

    df = pd.DataFrame(result)
    df.to_csv("./store/stage4_results.csv")
    print("Saved to ./store/stage4_results.csv")
    print(df)