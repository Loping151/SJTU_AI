import os
import subprocess
import glob
import argparse

def ply2glb(file_path, save_path):
    assert file_path.endswith(".ply") and save_path.endswith(".glb"), "Usage: gltf2glb(\"a.ply\", \"b.glb\")"
    subprocess.run(["blender", "-b", "-P", "./ply2glb.py", "--", file_path, save_path])
    
def search_for(directory, extension='ply'):
    files_with_extension = []
    search_pattern = os.path.join(directory, '**', f'*.{extension}')
    for file in glob.glob(search_pattern, recursive=True):
        files_with_extension.append(file)
    return files_with_extension

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare data to look better.")
    parser.add_argument("directory", type=str, help="File directory of a certain class")
    parser.add_argument("save_directory", type=str, help="Root directory to save the data, will be saved in a folder with the same name as the class")
    
    args = parser.parse_args()
    
    directory = args.directory
    save_directory = args.save_directory
    ply_files = search_for(directory, extension='ply')
    
    for ply_file in ply_files:
        glb_file = ply_file.split("/")[-2]+"-ply.glb"
        glb_file_path = os.path.join(save_directory, glb_file)
        ply2glb(ply_file, glb_file_path)
        print(f"Saved {ply_file} to {glb_file_path}")
        
    print(f"Saved all files in {save_directory}")