import bpy
import os
import sys

argv = sys.argv
argv = argv[argv.index("--") + 1:]

gltf_file = argv[0]
glb_file = argv[1]

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_by_type(type='MESH')
bpy.ops.object.delete()

bpy.ops.import_scene.gltf(filepath=gltf_file)

bpy.ops.export_scene.gltf(filepath=glb_file, export_format='GLB')

# blender -b -P tools/gltf2glb.py -- /path/to/input_file.gltf /path/to/output_file.glb

