import bpy
import json
import sys
import mathutils

argv = sys.argv
argv = argv[argv.index("--") + 1:]

ply_file_input = argv[0]
ply_file_output = argv[1]
pose_matrix = mathutils.Matrix(json.loads(argv[2]))

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_by_type(type='MESH')
bpy.ops.object.delete()

bpy.ops.import_mesh.ply(filepath=ply_file_input)

for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        obj.select_set(True)
    else:
        obj.select_set(False)
        
for obj in bpy.context.selected_objects:
    obj.matrix_world = pose_matrix
    
bpy.ops.export_mesh.ply(filepath=ply_file_output)