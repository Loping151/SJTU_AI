import os
import subprocess
import glob
import argparse


def glb2ply(file_path, save_path):
    assert file_path.endswith(".glb") and save_path.endswith(".ply"), "Usage: gltf2glb(\"a.glb\", \"b.ply\")"
    subprocess.run(["blender", "-b", "-P", "./glb2ply.py", "--", file_path, save_path])
    
def search_for(directory, extension='glb'):
    files_with_extension = []
    search_pattern = os.path.join(directory, '**', f'*.{extension}')
    for file in glob.glob(search_pattern, recursive=True):
        files_with_extension.append(file)
    return files_with_extension

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare data to look better.")
    parser.add_argument("directory", type=str, help="File directory of a certain class")
    parser.add_argument("save_directory", type=str, help="Root directory to save the data, will be saved in a folder with the same name as the class")
    
    args = parser.parse_args()
    
    directory = args.directory
    save_directory = args.save_directory
    glb_files = search_for(directory, extension='glb')
    
    for glb_file in glb_files:
        # if not '0ba93683289a21d0da65eebe782fbc48191722c0d3342b5c42d9311a29d0a192' in glb_file:
        #     continue # debug
        ply_file = glb_file.split("/")[-1].replace(".glb", ".ply")
        ply_file_path = os.path.join(save_directory, ply_file)
        glb2ply(glb_file, ply_file_path)
        print(f"Saved {glb_file} to {ply_file_path}")
        
    print(f"Saved all files in {save_directory}")