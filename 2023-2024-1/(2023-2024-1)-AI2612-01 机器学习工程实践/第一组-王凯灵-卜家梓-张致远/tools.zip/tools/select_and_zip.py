import os
import zipfile

def add_to_zip(zipfile_path, target_directory, condition_function):
    with zipfile.ZipFile(zipfile_path, 'w') as zipf:
        for foldername, _, filenames in os.walk(target_directory):
            for filename in filenames:
                if condition_function(filename):
                    file_path = os.path.join(foldername, filename)
                    zipf.write(file_path, os.path.relpath(file_path, target_directory))


# add_to_zip('recon_glb.zip', '../prepared_data', lambda filename: filename.endswith('-recon.glb'))
# add_to_zip('stage3_recon_ply2glb.zip', '../ml2023', lambda filename: filename.endswith('.glb'))
# add_to_zip('stage3_recon_12345_data.zip', '../ml2023', lambda filename: not filename.endswith('.glb'))
# add_to_zip('stage3_recon_ply.zip', 'data/12345_data', lambda filename: filename.endswith('.ply'))
# add_to_zip('stage2_original_glb.zip', 'data/back_up_data', lambda filename: filename.endswith('.glb') and not filename.endswith('-recon.glb'))
# add_to_zip('stage4_rotate_ply.zip', 'local_data/rotate_ply', lambda filename: filename.endswith('.ply'))
# add_to_zip('stage4_rotate_render_glb.zip', 'local_data/rotate_glb', lambda filename: filename.endswith('.png'))
# add_to_zip('stage4_recon_render_glb.zip', 'local_data/recon_glb', lambda filename: filename.endswith('.png'))
add_to_zip('stage2_selected_view', '/home/loping151/Disks/TiPlus7100/data/open/back_up_data', lambda filename: filename.endswith('.png'))