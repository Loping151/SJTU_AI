#!/bin/bash

source_directory="local_data/original_glb"
target_root_directory="local_data/rotate_glb"
json_root_directory="/home/loping151/Disks/TiPlus7100/data/12345_out_data"

process_directory() {
    local directory=$1
    local target_directory=$2

    mkdir -p "$target_directory"
    python rotate_glb.py "$directory" "$target_directory" "$json_directory"
    echo "Done: $directory"
}

for directory in "$source_directory"/*; do
    if [ -d "$directory" ]; then
        dirname=$(basename "$directory")
        target_directory="$target_root_directory/$dirname"
        json_directory="$json_root_directory/$dirname"

        process_directory "$directory" "$target_directory" "$json_directory" &
    fi
done

wait
echo "All done."
