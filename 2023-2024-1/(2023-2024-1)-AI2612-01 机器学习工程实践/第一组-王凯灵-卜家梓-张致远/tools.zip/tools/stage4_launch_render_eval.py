# Batch render all meshes in the folder DATA_DIR: ["examples/objaverse/", "examples/ours/"]
import os
import subprocess
import argparse

# Create an argument parser to accept the DATA_DIR as a command-line argument
parser = argparse.ArgumentParser()
parser.add_argument('--DATA_DIR', type=str, default='.', help='Path to the folder containing meshes to render')
args = parser.parse_args()

# The directory containing the extracted Blender
BLD_DIR = "/home/loping151/Documents/blender-4.0.1-linux-x64"
DATA_DIR = args.DATA_DIR
SCRIPT = "stage4_single_render_eval.py"
RESOLUTION = "512"

# Command to run
blenderproc_command = [
    "blenderproc",
    "run",
    "--custom-blender-path="+BLD_DIR,
    "--blender-install-path="+BLD_DIR,
    SCRIPT,
    "--object_path",
    "",
    "--output_dir",
    DATA_DIR,
    "--engine",
    "CYCLES",
    "--camera_dist",
    "1.3",
    "--resolution",
    RESOLUTION
]

for shape in os.listdir(DATA_DIR):
    print(f"Rendering {shape} ...")
    object_path = f"{DATA_DIR}/{shape}"
    blenderproc_command[6] = object_path
    blenderproc_command[8] = DATA_DIR
    subprocess.run(blenderproc_command)

