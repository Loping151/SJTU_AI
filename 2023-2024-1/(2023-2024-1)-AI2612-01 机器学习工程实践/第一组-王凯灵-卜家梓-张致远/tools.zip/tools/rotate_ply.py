import json
import subprocess
import argparse
import numpy as np
from prepare_data_glb import search_for
import os

def get_json(json_name):
    with open(json_name, 'r') as file:
        data = json.load(file)
    c2w_matrix = data['c2ws']['0.png']
    return c2w_matrix

polar_angles = np.radians([60] * 4 + [90] * 4)
azimuths = np.radians([*range(0, 360, 90)] * 2)

def get_rotate(idx):
    i = idx - 1
    
    def sample_camera_loc(phi=None, theta=None, r=1.0):
        x = r * np.sin(phi) * np.cos(theta)
        y = r * np.sin(phi) * np.sin(theta)
        z = r * np.cos(phi)
        return np.array([x, y, z])
    
    location = sample_camera_loc(polar_angles[i], azimuths[i], 1.5)
    
    forward_vector = np.array(location)
    forward_vector = forward_vector / np.linalg.norm(forward_vector)

    up_vector = np.array([0, 0, 1])

    right_vector = np.cross(up_vector, forward_vector)
    right_vector = right_vector / np.linalg.norm(right_vector)

    up_vector = np.cross(forward_vector, right_vector)
    up_vector = up_vector / np.linalg.norm(up_vector)

    rotation_matrix = np.column_stack((right_vector, up_vector, forward_vector))

    return rotation_matrix.transpose()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare data to look better.")
    parser.add_argument("directory", type=str, help="File directory of a certain class.")
    parser.add_argument("save_directory", type=str, help="Root directory to save the data, will be saved in a folder with the same name as the class.")
    
    parser.add_argument("json_directory", type=str, help="json file directory.")
    args = parser.parse_args()

    directory = args.directory
    save_directory = args.save_directory
    json_directory = args.json_directory

    json_names = search_for(json_directory, extension='json')

    backup_list = search_for('/home/loping151/Disks/TiPlus7100/data/back_up_data/'+json_directory.split('/')[-1], extension='png')
    rotate_id = {}
    for backup_name in backup_list:
        img_name = backup_name.split('/')[-1].split('.')[0]
        rotate_id[img_name[:-2]] = int(img_name[-1])
    
    for json_name in json_names:
        ply_path = os.path.join(directory, json_name.split("/")[-2]+".ply")
        save_path = os.path.join(save_directory, json_name.split("/")[-2]+".ply")
        
        c2w_matrix = np.eye(4)
        c2w_matrix[:3, :3] = np.array(get_json(json_name))[:3, :3]    
        c2w_matrix[:3, :3] = c2w_matrix[:3, :3] @ get_rotate(rotate_id[json_name.split("/")[-2]])
        subprocess.run(['blender', '-b', '-P', 'rotate_ply_blender.py', '--', ply_path, save_path, str(c2w_matrix.tolist())])