import shutil
import os
import glob

from prepare_data_gltf import search_for

ply_list = search_for('data/12345_data', extension='ply')
for ply in ply_list:
    shutil.move(ply, ply.replace('/mesh', ''))