#!/bin/bash

DIR="/local_data/clip_results"
EXTENSION=${1:-png}

count=$(find "$DIR" -name "*.$EXTENSION" | wc -l)

if [ $count -eq 0 ]; then
    echo "No .$EXTENSION file in $DIR."
    exit 0
fi

echo "Ready to remove $count .$EXTENSION files."

read -p "Remove? (y/[n]): " confirmation

if [[ $confirmation == [yY] ]]; then
    find "$DIR" -name "*.$EXTENSION" -exec rm {} +
    echo "All .$EXTENSION files removed."
else
    echo "User cancelled."
fi
