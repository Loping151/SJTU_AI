#!/bin/bash

if [ $# -lt 2 ]; then
    echo "Usage: $0 <WORK_DIR> --save or --load"
    exit 1
fi

WORK_DIR=$1

if [ ! -d "$WORK_DIR" ]; then
    echo "Do not exist: $WORK_DIR"
    exit 1
fi

case $2 in
    --save)
        SAVE_FILE="metadata/save-$(date +%Y%m%d%H%M%S).txt"
        find "$WORK_DIR" -type f -exec basename {} \; > "$SAVE_FILE"
        echo "Sync metadata saved: $SAVE_FILE"
        ;;
    --load)
        SAVE_FILE=$(ls metadata/save-*.txt 2>/dev/null | sort | tail -n 1)
        if [ -z "$SAVE_FILE" ]; then
            echo "No metadata file found."
            exit 1
        fi

        echo "Use metadata: $SAVE_FILE"
        echo "Processing: $WORK_DIR"

        mapfile -t saved_files < "$SAVE_FILE"

        to_keep=0
        to_delete=0

        for file in "$WORK_DIR"/*; do
            if [[ " ${saved_files[*]} " =~ $(basename "$file") ]]; then
                ((to_keep++))
            else
                ((to_delete++))
            fi
        done

        echo "Will keep: $to_keep"
        echo "Will delete: $to_delete"

        read -p "Delete? (y/[n]): " confirmation
        if [[ $confirmation == [yY] ]]; then
            for file in "$WORK_DIR"/*; do
                if ! [[ " ${saved_files[*]} " =~ $(basename "$file") ]]; then
                    rm "$file"
                fi
            done
            echo "Finished."
        else
            echo "User cancelled."
        fi
        ;;
    *)
        echo "Undefined command: $2"
        exit 1
        ;;
esac
