#!/bin/bash

declare -A ckpts
ckpts["sam_vit_h_4b8939.pth"]="https://huggingface.co/One-2-3-45/code/resolve/main/sam_vit_h_4b8939.pth"
ckpts["zero123-xl.ckpt"]="https://huggingface.co/One-2-3-45/code/resolve/main/zero123-xl.ckpt"
ckpts["elevation_estimate/utils/weights/indoor_ds_new.ckpt"]="https://huggingface.co/One-2-3-45/code/resolve/main/one2345_elev_est/tools/weights/indoor_ds_new.ckpt"
ckpts["reconstruction/exp/lod0/checkpoints/ckpt_215000.pth"]="https://huggingface.co/One-2-3-45/code/resolve/main/SparseNeuS_demo_v1/exp/lod0/checkpoints/ckpt_215000.pth"

for ckpt_name in "${!ckpts[@]}"; do
    ckpt_url="${ckpts[$ckpt_name]}"
    
    if [ -e "$ckpt_name" ]; then
        echo "File $ckpt_name already exists, skipping download."
        continue
    fi
    
    echo "Downloading checkpoint: $ckpt_name"
    wget -c "$ckpt_url" -O "$ckpt_name"

done
