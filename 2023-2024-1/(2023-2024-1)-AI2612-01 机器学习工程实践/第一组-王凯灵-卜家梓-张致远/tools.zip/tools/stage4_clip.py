from PIL import Image, ImageDraw, ImageFont
from tqdm import tqdm
import numpy as np
from prepare_data_gltf import search_for
import torch
import clip
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'Using device: {device}')

model, preprocess = clip.load("ViT-B/32", device=device)
cos = torch.nn.CosineSimilarity(dim=0)

def get_non_transparent_box(image):
    non_transparent = image.convert("RGBA").getchannel("A").getbbox()
    return non_transparent

def crop_non_transparent_area(img):
    bbox = get_non_transparent_box(img)
    if bbox:
        cropped_img = img.crop(bbox)
        return cropped_img
    else:
        return img
    
def similarity(image1_path, image2_path):
    image1 = Image.open(image1_path)
    image2 = Image.open(image2_path)
    
    image1_crop = crop_non_transparent_area(image1)
    image2_crop = crop_non_transparent_area(image2)
    
    image1_preprocess = preprocess(image1_crop).unsqueeze(0).to(device)
    image1_features = model.encode_image(image1_preprocess)

    image2_preprocess = preprocess(image2_crop).unsqueeze(0).to(device)
    image2_features = model.encode_image(image2_preprocess)

    similarity = cos(image1_features[0],image2_features[0]).item()
    # the author claim they did not do this:
    # similarity = (similarity+1)/2
    
    os.makedirs('./local_data/clip_results/'+image2_path.split('/')[-2], exist_ok=True)

    dst = Image.new('RGBA', (image1.width + image2.width, max(image1.height, image2.height)))
    dst.paste(image1, (0, 0))
    dst.paste(image2, (image1.width, 0))

    draw = ImageDraw.Draw(dst)
    font = ImageFont.truetype('./store/Times New Roman.ttf', 30)
    text = f'Similarity: {similarity:.2f}'
    text_position = (10, dst.height - 35)

    draw.text(text_position, text, font=font, fill=(0, 0, 0))

    dst.save('./local_data/clip_results/'+image2_path.split('/')[-2]+'/'+image2_path.split('/')[-1])


    return similarity
    
if __name__ == "__main__":
    result = {'category': [], 'model_hash': [], 'clips': [], 'clip mean': []}
    
    def add_result(category, model_hash, clips=[-1], clip_mean=-1):
        result['category'].append(category)
        result['model_hash'].append(model_hash)
        result['clips'].append(str(clips)[1:-1])
        result['clip mean'].append(clip_mean)
    
    recon_glb_list = sorted(search_for('local_data/recon_glb', extension='glb'))
    
    for glb_name in tqdm(recon_glb_list):
        category = glb_name.split('/')[-2]
        model_hash = glb_name.split('/')[-1].split('.')[0].replace('-recon', '')
        try:
            clips = []
            for idx in range(24):
                recon_image_path = glb_name.replace('.glb', f'-{idx+1}.png')
                rotate_image_path = recon_image_path.replace('recon_glb', 'rotate_glb').replace('-recon', '')
                clip_sim = similarity(recon_image_path, rotate_image_path)
                clips.append(clip_sim)
            add_result(category, model_hash, clips, np.mean(clips))
        except FileNotFoundError:
            print(f'FileNotFoundError: {glb_name}, maybe not 24 images.')
            add_result(category, model_hash)
    
    os.makedirs('./store', exist_ok=True)
    np.save('./store/stage4_clip.npy', result)