import os
import subprocess
import glob
import hashlib
import argparse

def get_hash_filename(file_path, extension='glb'):
    sha256_hash = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest() + f'.{extension}'

def glft2glb(file_path, save_path):
    assert file_path.endswith(".gltf") and save_path.endswith(".glb"), "Usage: gltf2glb(\"a.glft\", \"b.glb\")"
    subprocess.run(["blender", "-b", "-P", "./gltf2glb.py", "--", file_path, save_path])
    
def search_for(directory, extension='glb'):
    files_with_extension = []
    search_pattern = os.path.join(directory, '**', f'*.{extension}')
    for file in glob.glob(search_pattern, recursive=True):
        files_with_extension.append(file)
    return files_with_extension

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare data to look better.")
    parser.add_argument("directory", type=str, help="File directory of a certain class")
    parser.add_argument("save_directory", type=str, help="Root directory to save the data, will be saved in a folder with the same name as the class")
    
    args = parser.parse_args()
    
    directory = args.directory
    save_directory = args.save_directory
    gltf_files = search_for(directory, extension='gltf')
    
    for gltf_file in gltf_files:
        glb_file = get_hash_filename(gltf_file, extension='glb')
        glb_file_path = os.path.join(save_directory, glb_file)
        glft2glb(gltf_file, glb_file_path)
        print(f"Saved {gltf_file} to {glb_file_path}")
        
    print(f"Saved all files in {save_directory}")