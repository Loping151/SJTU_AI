import bpy
import json
import sys
import mathutils

argv = sys.argv
argv = argv[argv.index("--") + 1:]

glb_file_input = argv[0]
glb_file_output = argv[1]
pose_matrix = mathutils.Matrix(json.loads(argv[2]))

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_by_type(type='MESH')
bpy.ops.object.delete()
        
bpy.ops.import_scene.gltf(filepath=glb_file_input)

for obj in bpy.context.scene.objects:
    obj.matrix_world = pose_matrix @ obj.matrix_world
    
bpy.ops.export_scene.gltf(filepath=glb_file_output)