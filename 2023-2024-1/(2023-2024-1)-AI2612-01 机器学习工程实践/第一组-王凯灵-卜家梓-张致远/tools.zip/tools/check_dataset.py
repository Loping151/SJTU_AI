import argparse
import os

def check_files(directory):
    glb_files = {}
    png_files = {}
    error_files = []
    total_files = 0
    errors = 0

    for root, _, files in os.walk(directory):
        for file in files:
            total_files += 1
            if file.endswith('.glb'):
                base_name = os.path.splitext(file)[0]
                glb_files[base_name] = os.path.join(root, file)
            elif file.endswith('.png'):
                base_name = os.path.splitext(file)[0]
                base_name = base_name.rsplit('-', 1)[0]
                if base_name in png_files:
                    errors += 1
                    error_files.append(os.path.join(root, file))
                    print(f"Duplicate PNG file: {file}")
                png_files[base_name] = os.path.join(root, file)

    for base_name, glb_path in glb_files.items():
        if base_name not in png_files:
            errors += 1
            error_files.append(glb_path)
            print(f"Missing PNG file: {base_name}.png for {glb_path}")

    for base_name, png_path in png_files.items():
        if base_name not in glb_files:
            errors += 1
            error_files.append(png_path)
            print(f"Missing GLB file: {base_name}.glb for {png_path}")

    return total_files, errors, error_files

def main():
    parser = argparse.ArgumentParser(description="Check and optionally delete unmatched GLB and PNG files.")
    parser.add_argument("directory", type=str, help="Directory to check files in")
    args = parser.parse_args()

    total_files, errors, error_files = check_files(args.directory)

    print(f"Total files checked: {total_files}")
    print(f"Total errors found: {errors}")
    if errors > 0:
        print("Error files:")
        for file in error_files:
            print(file)

        delete = input("Do you want to delete these files? (y/[n]): ").lower()
        if delete == 'y':
            for file in error_files:
                os.remove(file)
                print(f"Deleted {file}")
        else:
            print("User cancelled.")

if __name__ == "__main__":
    main()

