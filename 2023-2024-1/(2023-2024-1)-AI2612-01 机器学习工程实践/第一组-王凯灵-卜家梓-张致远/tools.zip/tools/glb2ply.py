import bpy
import os
import sys

argv = sys.argv
argv = argv[argv.index("--") + 1:]

glb_file = argv[0]
ply_file = argv[1]

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_by_type(type='MESH')
bpy.ops.object.delete()

bpy.ops.import_scene.gltf(filepath=glb_file)

for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        obj.select_set(True)
    else:
        obj.select_set(False)

# 导出为 PLY 文件
bpy.ops.export_mesh.ply(filepath=ply_file)

# blender -b -P tools/gltf2glb.py -- /path/to/input_file.gltf /path/to/output_file.glb

