# Part 1：格式转换与视图渲染（已更改为多试图）

### stage
stage1: 原始数据收集

stage2: 单视图渲染与选取

stage3: 前向重建结果

stage4: 测评

### 格式转换

环境准备 (Tested on Ubuntu22.04)：

安装 blender：

```bash
sudo apt install blender # 非必须，仅用于格式转换，也可直接用提取的版本
```

```bash
whereis python3.10 # usually /usr/bin/python3.10
```

用以上的路径替换python路径，然后尝试

```
/usr/bin/python3.10 -m pip install blenderproc
```

如果提示没有pip（Ubuntu原生python初始时没有属于正常）：

```bash
wget https://bootstrap.pypa.io/get-pip.py
/usr/bin/python3.10 get-pip.py
rm get-pip.py
/usr/bin/python3.10 -m pip install blenderproc
```

非blender部分的脚本仅使用了自带模块和常见库，随便在虚拟环境中安装即可。

### 渲染(stage2)

当前使用八个试图，使用极角60、90和前后左右四个方向。

准备 blenderproc：这边使用下载的版本即可：https://www.blender.org/download/ ，建议选择较新的版本以支持RTX40*显卡。

格式转换和单图渲染：更改bash脚本中的数据路径，然后

```bash
bash gltf2glb.sh
bash stage2_render_all.sh
```

建议将数据存放在读写够快（>10Gbps）的硬盘，否则肉眼可见io瓶颈。满足io后，会使用最大系统资源执行，不建议同时进行其他操作。没收CPU约10分钟 (tested on Core i7-13700K)。

glb文件名为转换前gltf文件的sha256值，是为了防止重复和便于整理顺序。渲染得到的图片与glb文件同名，不同视角加上-1、-2等，是为了便于在保留完单个视图后改回与模型一致的名称。

# Part 2：工具与使用

注意：部分工具涉及相互调用，请下载和准备完整的工具脚本。本工具下载地址：http://download.loping151.com 下（服务期限2024年2月前）

### 重新渲染

提供了删除所有png的脚本。同理可以更改png为其他后缀，更改脚本中的路径后直接执行即可。

```bash
bash remove_ext.sh # png as default
# bash remove_ext.sh glb
```

### 其他格式转换

```bash
bash glb2ply.sh
bash ply2glb.sh
```

### 同步工具

假设你的路径：

```
prepared_data
|--bathhub
|  |-xxx.glb
|  |-xxx.png
|--bed
|  |-yyy.glb
|  |-yyy.png
```

执行：
```bash
python sync.py /path/to/data/prepared_data --save
```
将以当前时间为文件名保存metadata的txt文件。如含有鉴权模块，将自动同步至 http://sync.loping151.com

```bash
python sync.py /path/to/data/prepared_data --load
```
自动读取本地或云端最新的metadata并应用，按y确认。注意`最新`是按照字符串排序的，别随便改名。

为了兼容win和mac，`sync.sh`惨遭废弃。

### 检查工具

用于检查glb文件与png文件是否一一对应。只需要指定路径，并提供了自动清理未匹配文件的功能。

```bash
python check_dataset.py /path/to/data/prepared_data
```

### 压缩工具

用于将大文件夹中的指定文件添加值zip文件，用于同步和更新。详见文件`select_and_zip.py`内。

### 移动与整理

并非使用系统提供的文件搜索+剪切。大多为随手写的小脚本与已写的现成函数取用，不多介绍。

# Part 3：分析与测评

以下几乎所有bash脚本都涉及了路径的修改，不会反复提醒，自己注意。写bash脚本的目的主要是指明运行路径，以及分文件夹多线程地运行程序，以便提高效率的同时不触发过多的并发导致调度开销。由于为考虑各个文件夹的大小，所以实际上存在木桶效应，不过已经足够快。

### 测评部分渲染

```bash
bash stage_4_render_all.sh
```

用于完整地生成均匀的每30度的视角，分别对应与60度和90度的仰角共24个视角。

### 旋转模型

通过计算旋转矩阵以对齐。提供了`ply`和`glb`两种文件的旋转，详细计算过程见报告。
```bash
bash rotate_ply.sh
bash rotate_glb.sh
```

### clip 计算相似度

clip计算相似度包含了使用sam进行切割前景化图像，clip编码和计算余弦相似度。其中由于直接从模型渲染得到，本不存在背景。后两步使用通用的现成工具。修改目标文件夹路径后：

```bash
pip install sentence-transformer
python stage4_clip.py
```

### 3D距离计算

使用open3d计算相似度，并将结果保存为csv

```bash
python stage4_3D_distance.py
```