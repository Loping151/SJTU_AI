import argparse
import os
from datetime import datetime

def save_file_list(directory, save_file):
    file_cnt = 0
    with open(save_file, 'w') as file:
        for _, _, filenames in os.walk(directory):
            for filename in filenames:
                if '-recon' in filename: # only count raw files
                    continue
                file_cnt += 1
                file.write(filename + '\n')
    return file_cnt


def load_and_sync(directory, save_file):
    with open(save_file, 'r') as file:
        saved_files = set(file.read().splitlines())

    current_files = set()
    for _, _, filenames in os.walk(directory):
        current_files.update(filenames)

    to_keep = saved_files.intersection(current_files)
    to_delete = current_files - saved_files

    print(f"Will keep: {len(to_keep)} files")
    print(f"Will delete: {len(to_delete)} files")

    confirmation = input("Delete? (y/[n]): ")
    if confirmation.lower() == 'y':
        del_cnt = 0
        for filename in to_delete:
            for dirpath, _, filenames in os.walk(directory):
                if filename in filenames:
                    del_cnt += 1
                    print("\rDeleting", "{}/{}".format(del_cnt, len(to_delete)), f"{filename} ", end=" "*10)
                    os.remove(os.path.join(dirpath, filename))
        print("\nFinished.")
    else:
        print("User cancelled.")

def main():
    parser = argparse.ArgumentParser(description="File synchronization and deletion script")
    parser.add_argument("directory", help="The working directory")
    parser.add_argument("--save", action="store_true", help="Save the current list of files")
    parser.add_argument("--load", action="store_true", help="Load saved file list and synchronize")

    args = parser.parse_args()

    if not os.path.isdir(args.directory):
        print(f"Do not exist: {args.directory}")
        return

    if args.save:
        save_file = f"metadata/save-{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
        print('Found', save_file_list(args.directory, save_file), 'files.')
        print(f"Sync metadata saved: {save_file}")

    elif args.load:
        save_files = sorted([f for f in os.listdir('./metadata') if f.startswith('save-') and f.endswith('.txt')])
        if not save_files:
            print("No metadata file found.")
            return
        save_file = save_files[-1]
        print(f"Use metadata: {save_file}")
        load_and_sync(args.directory, save_file)

if __name__ == "__main__":
    main()
